<?php

$hostname = 'localhost';
$username = 'root';
$password = '';
$banco = 'pacific';

$conexao = new mysqli($hostname,$username,$password,$banco);

?>
