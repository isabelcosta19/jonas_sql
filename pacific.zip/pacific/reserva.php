<?php

  include('conexao.php');

  if (isset($_POST['enviar_form'])){

    $nome = $_POST['nome'];
    $checkin = $_POST['checkin'];
    $checkout = $_POST['checkout'];
    $email = $_POST['email'];
    $quarto = $_POST['quarto'];

    $inserir = mysqli_query($conexao,"INSERT INTO reserva VALUES('$nome','$checkin','$checkout','$email','$quarto')");
  
  };

  $conexao->close();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="hotel.css">
    <link rel="stylesheet" href="normalize.css">
</head>
<body>
  
  <header class="principal">
    <div>
      <h1 class="tema">Pacific Hotel</h1>
        <div class="menu">

        <a href="index.html">Inicio</a>
        <a href="about.html">Sobre Nós</a>
        <a href="quartos.html">Quartos</a>
        <a href="reserva.php">Simule sua reserva!</a>
    
        </div><!--menu-->
    
    </div>
    <h2 class="hotel">Hotel Pacific</h2>

  </header>
  <main>
    <div class="formulario">
      <form action="" method="post" class="simule">
        <label for="nome" class="formu">Nome Completo</label>
        <input type="text" name="nome" id="nome">
        <label for="checkin" class="formu">Data de check in</label>
        <input type="date" name="checkin" id="data">
        <label for="checkout" class="formu">Data de check out</label>
        <input type="date" name="checkout" id="data">
        <label for="email" class="formu">E-mail</label>
        <input type="email" name="email" id="email">            
        <label for="quarto" class="formu">Quartos</label>
        <select name="quarto" id="Uf" >
<option value="">Selecione</option>
<option value="Solteiro Standard">Solteiro Standard</option>
<option value="Solteiro Master">Solteiro Master</option>
<option value="Solteiro Duplo Standard">Solteiro Duplo Standard</option>
<option value="Casal Standard">Casal Standard</option>
<option value="Casal Master">Casal Master</option> <br> 
        <input type="submit" name="enviar_form" value="Enviar">
       <p>ENTRAREMOS EM CONTATO PELO EMAIL</P>
  </form>
    </div> 
  </main>
  <footer>
    <div class="baixo">
      <h1 class="black">Social</h1>
        <div class="baixo1" >
          <ul class="baixo_lista">
            <li><a class="lista" href="#">Facebook</a></li>
            <li><a class="lista" href="#">Instagram</a></li>
            <li><a class="lista" href="#">Twitter</a></li>
          </ul>
        </div>

    </div><!--baixo-->
    <div>
        <p class="whi">Todos os direitos reservado @pacific</p>
    </div>
  </footer>
</body>
</html>